#!/usr/bin/env python3
import sys, copy

import rospy
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from std_msgs.msg import Header

from geometry_msgs.msg import Pose, PoseStamped
import moveit_commander

import numpy as np
import moveit_msgs.msg
from moveit_msgs.msg import PositionIKRequest
from moveit_msgs.srv import GetPositionIK

class Arm_control():
    def __init__(self):
        self.a=JointTrajectory()
        self.block_pose = Pose()
        self.pub = rospy.Publisher('/arm_controller/command', JointTrajectory,queue_size=10)
        self.s = rospy.Subscriber('/block_pose', Pose, self.callback_block_pose)
        rospy.init_node('convert',anonymous=True)
        self.rate = rospy.Rate(10)

        joint_state_topic = ['joint_state:=/joint_states']
        moveit_commander.roscpp_initialize(joint_state_topic)
        self.robot = moveit_commander.RobotCommander()
        self.scene = moveit_commander.PlanningSceneInterface()
        self.arm = moveit_commander.MoveGroupCommander("arm")
        
    def callback_block_pose(self, data):
        self.block_pose = data

    def convert(self):
        
        joint_trajectory_msg=JointTrajectory()
        joint_trajectory_msg.joint_names = ["arm_base_joint","shoulder_joint", "bottom_wrist_joint", "elbow_joint","top_wrist_joint"]
        joint_trajectory_point = JointTrajectoryPoint()

        joint_trajectory_point.positions=[-0.1, 0.5, 0.02, 0, 0]
        joint_trajectory_point.positions=[0, 0, 0, 0, 0]
        joint_trajectory_point.time_from_start.secs = 1
        joint_trajectory_msg.points = [joint_trajectory_point] 
        self.a=joint_trajectory_msg
        while not rospy.is_shutdown():
            self.pub.publish(joint_trajectory_msg)
            self.rate.sleep()

    def go_to_marker(self):
        global block_pose 
        arm_current_pose = Pose()
        arm_current_pose = self.arm.get_current_pose()
        self.arm.clear_pose_targets()
        self.arm.set_goal_tolerance(0.08)
 

        target_pose = Pose()
        target_pose.position.x = self.block_pose.position.x
        target_pose.position.y = self.block_pose.position.y
        target_pose.position.z = self.block_pose.position.z+0.2
        target_pose.orientation.w = 0.5
        #target_pose.header.frame_id = self.arm.get_end_effector_link()
        self.arm.set_pose_target(target_pose)
        plan=self.arm.go(wait=True) 
        self.arm.stop
        #waypoints.append(copy.deepcopy(target_pose))
        #print("target pose")
        #print(target_pose)
        #(plan, fraction) = self.arm.compute_cartesian_path(waypoints, 0.01, 0.0)  # waypoints to follow  # eef_step
        #self.arm.execute(plan, wait=True)
        


    
if __name__ == '__main__':
    x=Arm_control()
    x.go_to_marker()
    